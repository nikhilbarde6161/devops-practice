# DevOps Portfolio – AWS EKS, GitOps, Monitoring & Terraform

This repository contains three GitHub-ready DevOps projects:

1. **CI/CD Pipeline with GitHub Actions + Argo CD on AWS EKS**
2. **Dockerized Node.js Web App with Prometheus + Grafana + Alertmanager**
3. **AWS Infrastructure Provisioning with Terraform**

## Repository structure

```text
devops-portfolio/
├── .gitignore
├── README.md
├── cicd-argocd-eks/
│   ├── app/
│   │   ├── Dockerfile
│   │   ├── package.json
│   │   └── server.js
│   ├── k8s/
│   │   ├── deployment.yaml
│   │   └── service.yaml
│   ├── argocd/
│   │   └── application.yaml
│   └── .github/workflows/ci.yml
├── monitoring/
│   ├── app/
│   │   ├── Dockerfile
│   │   ├── package.json
│   │   └── server.js
│   ├── k8s/
│   │   ├── namespace.yaml
│   │   ├── app.yaml
│   │   ├── prometheus-config.yaml
│   │   ├── prometheus.yaml
│   │   ├── grafana.yaml
│   │   └── alertmanager.yaml
│   └── README.md
└── terraform-aws/
    ├── versions.tf
    ├── provider.tf
    ├── variables.tf
    ├── vpc.tf
    ├── iam.tf
    ├── ec2.tf
    ├── s3.tf
    ├── outputs.tf
    ├── terraform.tfvars.example
    └── .gitignore
```

## Important

- Do not commit AWS access keys, private keys, `.tfstate`, kubeconfigs, or secrets.
- The EKS Terraform project creates billable AWS resources. Destroy them when finished:
  `terraform destroy`
- GitHub Actions uses GitHub's OIDC federation pattern instead of storing long-lived AWS keys.

## Quick Git commands

```bash
git init
git add .
git commit -m "Initial DevOps portfolio projects"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/devops-portfolio.git
git push -u origin main
```
