# Prometheus + Grafana Monitoring

## 1. Build the application

```bash
cd app
npm install
docker build -t YOUR_DOCKERHUB_USERNAME/monitoring-demo:latest .
docker push YOUR_DOCKERHUB_USERNAME/monitoring-demo:latest
```

Update the image in `k8s/app.yaml`.

## 2. Deploy

```bash
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/app.yaml
kubectl apply -f k8s/prometheus-config.yaml
kubectl apply -f k8s/prometheus.yaml
kubectl apply -f k8s/grafana.yaml
kubectl apply -f k8s/alertmanager.yaml
```

## 3. Access

```bash
kubectl -n monitoring-demo get pods
kubectl -n monitoring-demo port-forward svc/prometheus 9090:9090
kubectl -n monitoring-demo port-forward svc/grafana 3000:3000
```

Grafana default credentials in this demo are `admin/admin123`. Change them for any real environment.
