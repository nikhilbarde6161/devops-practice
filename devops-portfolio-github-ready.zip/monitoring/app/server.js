const express = require("express");
const client = require("prom-client");

const app = express();
const port = process.env.PORT || 3000;

client.collectDefaultMetrics();

const httpRequests = new client.Counter({
  name: "http_requests_total",
  help: "Total HTTP requests",
  labelNames: ["method", "route", "status"]
});

app.use((req, res, next) => {
  res.on("finish", () => {
    httpRequests.inc({
      method: req.method,
      route: req.path,
      status: res.statusCode
    });
  });
  next();
});

app.get("/", (_req, res) => {
  res.json({ application: "monitoring-demo", status: "ok" });
});

app.get("/health", (_req, res) => res.send("OK"));

app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", client.register.contentType);
  res.end(await client.register.metrics());
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Monitoring app listening on ${port}`);
});
