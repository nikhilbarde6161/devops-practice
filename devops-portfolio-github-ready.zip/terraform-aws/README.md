# AWS Infrastructure with Terraform

This project provisions:

- VPC
- Public and private subnets
- Internet Gateway
- Public route table
- EC2 instance
- IAM role and instance profile
- S3 bucket

## Run

```bash
terraform init
terraform fmt -recursive
terraform validate
terraform plan
terraform apply
```

Use `terraform.tfvars.example` as the starting point for local variables.

## Destroy

```bash
terraform destroy
```

The EC2/S3 resources and any associated AWS usage can incur charges depending on your account and region. Check AWS pricing/free-tier eligibility before applying.
